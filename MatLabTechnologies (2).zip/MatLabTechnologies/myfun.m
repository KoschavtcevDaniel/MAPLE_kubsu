function f = myfun(x)
f = exp(-x).*sqrt((x.^2+pi)./(x.^4+sin(x)));
