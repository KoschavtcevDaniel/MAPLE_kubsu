function g = func2(x)
g = 6.*cos(x)+x.^2.*sin(x);