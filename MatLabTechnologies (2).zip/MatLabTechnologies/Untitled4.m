n = input('Rows ')
m = input('Columns ')
A = rand(n, m)