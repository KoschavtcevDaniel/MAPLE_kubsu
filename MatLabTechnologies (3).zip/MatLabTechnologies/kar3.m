x = 0:0.1:4;
y = func1(x);
figure(1)
fplot('func1', [-10, 10])
grid on
x1 = fzero('func1', -8)
x2 = fzero('func1', -5)
x3 = fzero('func1', -2)
x4 = fzero('func1', 2)
x5 = fzero('func1', 5)
x6 = fzero('func1', 8)
figure(2);
[x, y] = meshgrid(-1:0.01:1, -1:0.01:1);
g = func2(x, y);
mesh(x, y, g)
colormap('copper')
shading interp
xlabel('ostavaisy takoi kak est')
ylabel('Ne smotri ti po storonam')
zlabel('Ne smotri')
