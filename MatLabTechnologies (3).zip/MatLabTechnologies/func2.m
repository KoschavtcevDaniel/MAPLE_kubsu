function g = func2(x1, x2)
g = abs(x1 - 10) + abs(x2 - 6);