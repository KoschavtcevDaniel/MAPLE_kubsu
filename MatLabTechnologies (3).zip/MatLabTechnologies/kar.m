n = 5;
m = 6;
A = rand(m, n);
ind = 1;
jnd = 1;
mx = max(max(A));
for i=1:m
    for j=1:n
        if A(i, j) > mx
            mx = A(i, j);
            ind = j;
        end
    end
end
i = 1:1:n;
b = sin(log(i) + cos(i));
B = zeros(m, n);
B = B + A;
B(ind, :) = b;
B
A