function f = func1(x)
f = -3 * cos(x);
