figure;
x = 0.01:0.01:2;
f1 = sin(x).*cos(x);
subplot(3,3,1)
plot(x, f1)
grid on
xlabel('He-he')
ylabel('Ha-ha')
legend('Ya legenda!!!', 'Ya ne legenda((');
f2 = cos(x).*(x.^2);
subplot(3,3,3)
plot(x, f2)
grid on
xlabel('He-he')
ylabel('Ha-ha')
legend('Ya legenda!!!', 'Ya ne legenda((');
f3 = x.^2.*log(x);
subplot(3,3,5)
plot(x, f3)
grid on
xlabel('He-he')
ylabel('Ha-ha')
legend('Ya legenda!!!', 'Ya ne legenda((');
f4 = log(x).*exp(x);
subplot(3,3,7)
plot(x, f4)
grid on
xlabel('He-he')
ylabel('Ha-ha')
legend('Ya legenda!!!', 'Ya ne legenda((');
